#!/usr/bin/env python

# foutre
# a web site compiler
#
# requirements:
# -> markdown
# -> mako

import os
import argparse
from markdown import markdown
import sys
import string
import time
from stat import *
from mako.template import Template
import shutil
from math import ceil

def slugify(name):
    '''
    creates a nice url-friendly slug out of a string
    name = the string to slugify, of course
    '''
    if name == '': return ''
    name = string.replace(name," ","-")
    name = string.lower(name)
    return name

def make_single_page(post,tmpl_dir,dest):
    '''
    post = dictionary of post meta data
    destination = the place to put the resulting rendered post
    '''
    postfile = open(post['path'],'r')
    contents = markdown(string.split(postfile.read(),"***",1)[1],
            output_format='html')
    postfile.close()
    if "template" in post.keys():
        tmpl = "%s.html" % (post['template'],)
    else:
        tmpl = "single-page.html"

    t = Template(filename=os.path.join(tmpl_dir,tmpl),
            module_directory=tmpl_dir)
    catlist = []
    for cat in post['categories']:
        catlist.append((cat,slugify(cat)))
    tmpl_out = t.render(
            title=post['title'],
            content=contents,
            created=post['created'],
            modified=post['modified'],
            slug=post['slug'],
            cats=catlist
            )

    # now write the output to the destination
    outfile = open(os.path.join(dest,"%s.html" % (post['slug'],)),'w')
    outfile.write(tmpl_out)
    outfile.close()
    return True

def make_category(cat,posts,tmpl_dir,dest,pagination):
    '''
    cat = category name
    posts = list of post meta data dictionaries
    tmpl_dir = template directory
    destination = the place to put the resulting rendered files
    pagination = number of posts per page
    '''
    s = slugify(cat)
    if not os.path.exists(os.path.join(dest,s)):
        os.mkdir(os.path.join(dest,s))
    t = Template(filename=os.path.join(tmpl_dir,'category.html'),
            module_directory=tmpl_dir)

    pages = int(ceil(float(len(posts))/float(pagination)))
    if pages == 1:
        tmpl_out = t.render(
                title=cat,
                posts=posts,
                pagenum=1
                )
        # there is only one page so open up index and put it in there
        index = open(os.path.join(dest,s,'index.html'),'w')
        index.write(tmpl_out)
        index.close()
    else:
        for i in range(0,pages):
            start = (i*pagination)
            if len(posts[start:]) >= pagination:
                end = start+pagination
            else:
                end = len(posts[start:])+2
            tmpl_out = t.render(
                    title=cat,
                    posts=posts[start:end],
                    pagenum=i+1
                    )
            # create a page
            out = open(os.path.join(dest,s,'page-%d.html' % (i+1,)),'w')
            out.write(tmpl_out)
            out.close()
        shutil.copy(os.path.join(dest,s,'page-1.html'),
                    os.path.join(dest,s,'index.html'))

def collect(postdir):
    '''
    postdir = input directory containing the posts (src, for now)
    '''
    posts = [meta_for_file(os.path.join(postdir,post))
            for post in os.listdir(postdir) if post.endswith(".txt")] 
    cats = []
    for post in posts:
        for cat in post['categories']:
            if cat is not "" and cat not in cats:
                cats.append(cat)
    return (posts,cats)

def meta_for_file(postfile):
    '''
    postfile = the path to a post
    this function grabs the meta data for a post
    '''
    metadict = {}
    metadict['slug'] = os.path.split(postfile)[1][:-4]
    metadict['modified'] = str(os.stat(postfile)[ST_MTIME])

    post = open(postfile,'r')
    contents = post.read()
    meta = string.split(contents,"***",1)[0]
    lines = meta.splitlines(False)
    for line in lines:
        if line is not "" and line.strip() != "page".strip():
            l = string.split(line,":",1)
            metadict[l[0].strip()] = l[1].strip()
        if line.strip() == "page".strip(): metadict['page'] = True
    # split categories up
    categories = metadict['categories']
    catlist = string.split(categories,"|")
    metadict['categories'] = []
    for cat in catlist:
        metadict['categories'].append(cat.strip())
    metadict['path'] = postfile
    if 'page' in metadict and metadict['page'] == True:
        metadict['categories'] = ''

    if 'page' not in metadict.keys():
        metadict['page'] = False

    post.close()

    if "created" not in metadict.keys():
        metadict['created'] = metadict['modified']
        # put it in the file
        post = open(postfile,'w')
        post.write("created: %s\n%s" % (metadict['created'],contents))
        post.close()

    return metadict

if __name__=="__main__":
    parser = argparse.ArgumentParser(description="foutre - a website compiler")
    parser.add_argument('-o','--output',action='store',type=str,
            required=True)
    parser.add_argument('-i','--input',action='store',type=str,required=False,
            default=os.getcwd())
    parser.add_argument('-p','--pagination',action='store',type=int,required=False,
            default=10)

    args = parser.parse_args()
    outputdir = args.__dict__['output'] 
    inputdir = args.__dict__['input'] 
    pagination = args.__dict__['pagination']

    # check if output directory exists
    if os.path.exists(outputdir):
        shutil.rmtree(outputdir)
    os.mkdir(outputdir)
    os.mkdir(os.path.join(outputdir,'pages'))
    os.mkdir(os.path.join(outputdir,'category'))

    if not os.path.exists(inputdir):
        print "%s does not exist" % (inputdir,)
        exit(1)

    # now for the extraordinary part: build a giant metadata dictionary
    (postmeta, categories) = collect(os.path.join(inputdir,"src"))

    # for each post, create a single page using the specified template or
    # default (single_page) in outputdir/page/{slug}.html
    for post in postmeta:
        make_single_page(post,
                         os.path.join(inputdir,"templates"),
                         os.path.join(outputdir,"pages"))

    # for each category, create a list of posts and every {pagination} posts,
    # create a page under outputdir/category/{cat_name}/page-{N}.html
    for cat in categories:
        posts = [post for post in postmeta if cat in post['categories'] and
                not post['page']]
        make_category(cat,
                      posts,
                      os.path.join(inputdir,"templates"),
                      os.path.join(outputdir,"category"),
                      pagination)

    # if index.txt exists, treat it like a single page.
    # if it doesn't, create a category-like page series (each page has
    # {pagination} posts. 
    if os.path.exists(os.path.join(inputdir,"index.txt")):
        index_meta = meta_for_file(os.path.join(inputdir,"index.txt"))
        make_single_page(index_meta,os.path.join(inputdir,"templates"),outputdir)
    else:
        make_category("",postmeta,
                      os.path.join(inputdir,"templates"),
                      outputdir,pagination)

    shutil.copytree(os.path.join(inputdir,"resources"),
                os.path.join(outputdir,"resources"))

    # and we're done!
    exit(0)
